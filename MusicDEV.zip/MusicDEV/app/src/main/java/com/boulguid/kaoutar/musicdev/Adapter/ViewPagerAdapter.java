package com.boulguid.kaoutar.musicdev.Adapter;


import android.content.ContentResolver;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.boulguid.kaoutar.musicdev.Fragments.AllSongFragment;
import com.boulguid.kaoutar.musicdev.Fragments.FavSongFragment;

public class ViewPagerAdapter extends FragmentPagerAdapter {

    private ContentResolver contentResolver;
    private String title[] = {"MUSIQUES","PLAYLIST FAVORIS"};

    public ViewPagerAdapter(FragmentManager fm, ContentResolver contentResolver) {
        super(fm);
        this.contentResolver = contentResolver;
    }

    //Afficher l'item selon la position où on est
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return AllSongFragment.getInstance(position, contentResolver);
            case 1:
                return FavSongFragment.getInstance(position);
            default:
                return null;
        }
    }

    //Total des music
    @Override
    public int getCount() {
        return title.length;
    }

    //Afficher titre de la chanson en haut
    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return title[position];
    }
}

