package com.boulguid.kaoutar.musicdev.Model;


public class SongsList {

    private String titre;
    private String artiste;
    private String path;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public SongsList(String title, String subTitle, String path) {
        this.titre = title;
        this.artiste = subTitle;
        this.path = path;

    }

    public String getTitle() {
        return titre;
    }

    public void setTitle(String title) {
        this.titre = title;
    }

    public String getSubTitle() {
        return artiste;
    }

}
