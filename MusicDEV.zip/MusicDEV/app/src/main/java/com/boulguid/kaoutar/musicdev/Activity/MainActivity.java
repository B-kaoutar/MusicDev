package com.boulguid.kaoutar.musicdev.Activity;

import android.Manifest;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SearchView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.boulguid.kaoutar.musicdev.Adapter.ViewPagerAdapter;
import com.boulguid.kaoutar.musicdev.DB.FavoritesOperations;
import com.boulguid.kaoutar.musicdev.Fragments.AllSongFragment;
import com.boulguid.kaoutar.musicdev.Fragments.FavSongFragment;
import com.boulguid.kaoutar.musicdev.Model.SongsList;
import com.boulguid.kaoutar.musicdev.R;import static com.boulguid.kaoutar.musicdev.Activity.MediaPlayerService.*;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AllSongFragment.createDataParse, FavSongFragment.createDataParsed, SensorEventListener {

    //Pour Sensor
    private SensorManager sensorManager;
    private Sensor sensor;
    float cx,cy,cz;
    float lastx,lasty,lastz;
    boolean notfirsttime=false;
    float shake=5f;




    //Variables Pour les boutons de controls
    private ImageButton contrl, replay, precedent, suivant, nextMusic;

    //Variables Pour la durée de la chanson
    private TextView courant, total;
    private SeekBar seekbarController;

    //Variables Layouts
    private DrawerLayout mDrawerLayout;
    private TabLayout tabLayout;
    private ViewPager viewPager;


    //Menu
    private Menu menu;

    //Listes des musiques
    private ArrayList<SongsList> listMusic;
    private int positionAcc;
    private String recher = "";
    private SongsList musicAcc;


    private boolean controlleurM = false, repetitionM = false, continuerM = false, maPlaylist = true;
    private final int MY_PERMISSION_REQUEST = 100;

    private int totalMusic;

    NavigationView navigationView;
    Toolbar toolbar;

    //Bouton pour actualiser
    FloatingActionButton actualiser;

    MediaPlayer mediaPlayer;
    Handler handler;
    Runnable runnable;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        grantedPermission();

        //Pour background service
        Intent intent = new Intent(getApplication(), MediaPlayerService.class);
        intent.setAction(MediaPlayerService.ACTION_PLAY);
        startService(intent);

        /**
         * Pour le Sensor
         */

        sensorManager= (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)!=null){
            sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        }else{
            Toast.makeText(getApplicationContext(),"Aucun sensor ! ", Toast.LENGTH_SHORT).show();
        }

    }

    /**
     * Initialiser View
     */

    private void init() {

        precedent = findViewById(R.id.before);
        suivant = findViewById(R.id.next);
        replay = findViewById(R.id.replay);
        nextMusic = findViewById(R.id.cont);

        courant = findViewById(R.id.debut);
        total = findViewById(R.id.duree);
        actualiser = findViewById(R.id.refresh);
        seekbarController = findViewById(R.id.sController);
        viewPager = findViewById(R.id.songs_viewpager);
        navigationView = findViewById(R.id.navig);
        mDrawerLayout = findViewById(R.id.drawer_layout);
        contrl = findViewById(R.id.play);
        toolbar = findViewById(R.id.toolbar);
        tabLayout = findViewById(R.id.tabs);

        handler = new Handler();
        mediaPlayer = new MediaPlayer();

        toolbar.setTitleTextColor(getResources().getColor(R.color.text_color));
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.menu_icon);

        suivant.setOnClickListener(this);
        precedent.setOnClickListener(this);
        replay.setOnClickListener(this);
        actualiser.setOnClickListener(this);
        contrl.setOnClickListener(this);
        nextMusic.setOnClickListener(this);

        //Pour le menu
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                item.setChecked(true);
                mDrawerLayout.closeDrawers();
                switch (item.getItemId()) {
                    case R.id.apropos:
                        about();
                        break;
                }
                return true;
            }
        });
    }

    /**
     * Pour assurer les permissions
     */

    private void grantedPermission() {
        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, MY_PERMISSION_REQUEST);
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                    Manifest.permission.READ_EXTERNAL_STORAGE))
            {
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, MY_PERMISSION_REQUEST);
            }
            else
                {
                if (ContextCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    Snackbar snackbar = Snackbar.make(mDrawerLayout, "Autorisation de stockage requise", Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            }
        }
        else
            {
            setPagerLayout();
            }
    }

    /**
     * Vérifier des Autorisations
     *
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case MY_PERMISSION_REQUEST:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    if (ContextCompat.checkSelfPermission(MainActivity.this,
                            Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
                    {
                        Toast.makeText(this, "Les permissions sont autorisées", Toast.LENGTH_SHORT).show();
                        setPagerLayout();
                    }
                    else
                        {
                        Snackbar snackbar = Snackbar.make(mDrawerLayout, "Autorisation de stockage requise", Snackbar.LENGTH_LONG);
                        snackbar.show();
                        finish();
                        }
                }
        }
    }

    /**
     * Configuration de la mise en page avec Viewpager.
     */

    private void setPagerLayout() {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager(), getContentResolver());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener()
        {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


        //Pour que la mise en page s'adapte à chaque taille et orientation d'écran
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        tabLayout.setupWithViewPager(viewPager);

        //on se glisse à l'item qu'on selecte
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener()
        {

            @Override
            public void onTabSelected(TabLayout.Tab tab)
            {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }

    /**
     * About us (Dans le menu)
     */
    private void about() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.about))
                .setMessage(getString(R.string.about_text))
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    //Pour la recherche des musiques
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.menu = menu;
        getMenuInflater().inflate(R.menu.action_bar_menu, menu);
        SearchManager manager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        SearchView searchView = (SearchView) menu.findItem(R.id.search).getActionView();
        searchView.setSearchableInfo(manager.getSearchableInfo(getComponentName()));
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                recher = newText;
                queryText();
                setPagerLayout();
                return true;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    //Selection selon l'item qu'on veux
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                mDrawerLayout.openDrawer(Gravity.START);
                return true;
            case R.id.search:
                Toast.makeText(this, "Rechercher", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.playlist:
                if (controlleurM)
                    if (mediaPlayer != null) {
                        if (maPlaylist)
                        {
                            Toast.makeText(this, "Ajoutée à votre playlist préférée", Toast.LENGTH_SHORT).show();
                            item.setIcon(R.drawable.ic_favorite_filled);
                            SongsList favList = new SongsList(listMusic.get(positionAcc).getTitle(),
                                    listMusic.get(positionAcc).getSubTitle(), listMusic.get(positionAcc).getPath());
                            FavoritesOperations favoritesOperations = new FavoritesOperations(this);
                            favoritesOperations.addSongFav(favList);
                            setPagerLayout();
                            maPlaylist = false;
                        }
                        else
                            {
                            item.setIcon(R.drawable.favorite_icon);
                            maPlaylist = true;
                        }
                    }
                return true;
        }

        return super.onOptionsItemSelected(item);

    }


    /**
     * Fonctions de Music
     *
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.refresh:
                Toast.makeText(this, "Page actualisée", Toast.LENGTH_SHORT).show();
                setPagerLayout();
                break;
            case R.id.play:
                if (controlleurM)
                {
                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.pause();
                        contrl.setImageResource(R.drawable.play_icon);
                    } else if (!mediaPlayer.isPlaying()) {
                        mediaPlayer.start();
                        contrl.setImageResource(R.drawable.pause_icon);
                        playCycle();
                    }
                }
                else
                    {
                    Toast.makeText(this, "Veuillez selectionner la musique que vous voulez écouter", Toast.LENGTH_SHORT).show();
                    }
                break;
            case R.id.before:
                if (controlleurM) {
                    if (mediaPlayer.getCurrentPosition() > 10)
                    {
                        if (positionAcc - 1 > -1)
                        {
                            attachMusic(listMusic.get(positionAcc - 1).getTitle(), listMusic.get(positionAcc - 1).getPath());
                            positionAcc = positionAcc - 1;
                        } else {
                            attachMusic(listMusic.get(positionAcc).getTitle(), listMusic.get(positionAcc).getPath());
                        }
                    }
                    else
                        {
                        attachMusic(listMusic.get(positionAcc).getTitle(), listMusic.get(positionAcc).getPath());
                        }
                }
                else
                    {
                    Toast.makeText(this, "Veuillez selectionner la musique que vous voulez écouter", Toast.LENGTH_SHORT).show();
                    }
                break;
            case R.id.next:
                if (controlleurM)
                {
                    if (positionAcc + 1 < listMusic.size())
                    {
                        attachMusic(listMusic.get(positionAcc + 1).getTitle(), listMusic.get(positionAcc + 1).getPath());
                        positionAcc += 1;
                    }
                    else
                        {
                        Toast.makeText(this, "Fin de la liste de musique", Toast.LENGTH_SHORT).show();
                        }
                }
                else
                    {
                    Toast.makeText(this, "Veuillez selectionner la musique que vous voulez écouter", Toast.LENGTH_SHORT).show();
                    }
                break;
            case R.id.replay:
                if (repetitionM)
                {
                    Toast.makeText(this, "Répitition désactivée", Toast.LENGTH_SHORT).show();
                    mediaPlayer.setLooping(false);
                    repetitionM = false;
                }
                else
                    {
                    Toast.makeText(this, "Répitition Activée", Toast.LENGTH_SHORT).show();
                    mediaPlayer.setLooping(true);
                    repetitionM = true;
                    }
                break;
            case R.id.cont:
                if (!continuerM)
                {
                    continuerM = true;
                    Toast.makeText(this, "Le continuement est activé", Toast.LENGTH_SHORT).show();
                }
                else
                    {
                    continuerM = false;
                    Toast.makeText(this, "Le continuement est désactivé", Toast.LENGTH_SHORT).show();
                    }
                break;
        }
    }

    /**
     * Ecouter de la musique
     *
     */

    private void attachMusic(String name, String path) {
        contrl.setImageResource(R.drawable.play_icon);
        setTitle(name);
        menu.getItem(1).setIcon(R.drawable.favorite_icon);
        maPlaylist = true;

        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(path);
            mediaPlayer.prepare();
            setControls();
        } catch (Exception e) {
            e.printStackTrace();
        }
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                contrl.setImageResource(R.drawable.play_icon);
                if (continuerM)
                {
                    if (positionAcc + 1 < listMusic.size())
                    {
                        attachMusic(listMusic.get(positionAcc + 1).getTitle(), listMusic.get(positionAcc + 1).getPath());
                        positionAcc += 1;
                    } else {
                        Toast.makeText(MainActivity.this, "Fin de la liste de musique", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    /**
     * Controler la musique
     */

    private void setControls() {

        //Avoir la durée de la musique
        seekbarController.setMax(mediaPlayer.getDuration());
        mediaPlayer.start();
        playCycle();
        controlleurM = true;

        //Changement l'icone en Pause
        if (mediaPlayer.isPlaying())
        {
            contrl.setImageResource(R.drawable.pause_icon);
            total.setText(getTimeFormatted(mediaPlayer.getDuration()));
        }

        //Si l'utilisateur veux avancer la musique ou le contraire
        seekbarController.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    mediaPlayer.seekTo(progress);
                    courant.setText(getTimeFormatted(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    /**
     * Ecouter de la musique avec thread
     */

    //Ecouter musique
    private void playCycle() {
        try {
            //seekbar est variable en fonction de la musique
            seekbarController.setProgress(mediaPlayer.getCurrentPosition());
            courant.setText(getTimeFormatted(mediaPlayer.getCurrentPosition()));
            if (mediaPlayer.isPlaying())
            {
                runnable = new Runnable() {
                    @Override
                    public void run() {
                        playCycle();

                    }
                };
                handler.postDelayed(runnable, 100);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Pour avoir le temps de la musique
    private String getTimeFormatted(long milliSeconds)
    {
        String finalTimerString = "";
        String secondsString;

        //Converting total duration into time
        int hours = (int) (milliSeconds / 3600000);
        int minutes = (int) (milliSeconds % 3600000) / 60000;
        int seconds = (int) ((milliSeconds % 3600000) % 60000 / 1000);

        // Adding hours if any
        if (hours > 0)
            finalTimerString = hours + ":";

        // Prepending 0 to seconds if it is one digit
        if (seconds < 10)
            secondsString = "0" + seconds;
        else
            secondsString = "" + seconds;

        finalTimerString = finalTimerString + minutes + ":" + secondsString;

        // Return timer String;
        return finalTimerString;
    }


   // Passer des donnée comme pour favoris
    @Override
    public void onDataPass(String name, String path) {
        Toast.makeText(this, name, Toast.LENGTH_LONG).show();
        attachMusic(name, path);
    }

    //Total de music
    @Override
    public void getLength(int length) {
        this.totalMusic = length;
    }

    //Liste des music
    @Override
    public void fullSongList(ArrayList<SongsList> songList, int position) {
        this.listMusic = songList;
        this.positionAcc = position;

    }

    //Pour le format du texte
    @Override
    public String queryText() {
        return recher.toLowerCase();
    }




    @Override
    public void currentSong(SongsList songsList) {
        this.musicAcc = songsList;
    }

    @Override
    public int getPosition() {
        return positionAcc;
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.release();
        handler.removeCallbacks(runnable);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        cx=sensorEvent.values[0];
        cy=sensorEvent.values[1];
        cz=sensorEvent.values[2];

        if(notfirsttime){
            float xdiff=Math.abs(lastx-cx);
            float ydiff=Math.abs(lasty-cy);
            float zdiff=Math.abs(lastz-cz);

            if((xdiff>shake && ydiff > shake)||(xdiff >shake && zdiff>shake)||(ydiff>shake && zdiff >shake)){
                suivant.callOnClick();
            }
        }

        lastx =cx;
        lastx =cy;
        lastx =cz;

        notfirsttime=true;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}