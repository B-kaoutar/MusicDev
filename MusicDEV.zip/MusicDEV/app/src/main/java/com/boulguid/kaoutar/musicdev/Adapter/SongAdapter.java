package com.boulguid.kaoutar.musicdev.Adapter;

import android.content.Context;
import android.content.Context;
import android.graphics.Movie;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filterable;
import android.widget.TextView;

import com.boulguid.kaoutar.musicdev.Model.SongsList;
import com.boulguid.kaoutar.musicdev.R;

import java.util.ArrayList;
import java.util.List;

public class SongAdapter extends ArrayAdapter<SongsList> implements Filterable{

    private Context context;

    private ArrayList<SongsList> listMusic = new ArrayList<>();

    //Liste de music
    public SongAdapter(Context context, ArrayList<SongsList> listMusic)
    {
        super(context, 0, listMusic);
        this.context = context;
        this.listMusic = listMusic;
    }

    //Affichage de la liste des musiques
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
    {
        View listItem = convertView;
        if (listItem == null) {
            listItem = LayoutInflater.from(context).inflate(R.layout.playlist_items, parent, false);
        }
        SongsList currentSong = listMusic.get(position);
        TextView tvTitle = listItem.findViewById(R.id.nomMusic);
        TextView tvSubtitle = listItem.findViewById(R.id.artiste);
        tvTitle.setText(currentSong.getTitle());
        tvSubtitle.setText(currentSong.getSubTitle());
        return listItem;
    }
}

